package com.ed.api_gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
//@EnableEurekaClient
class ApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
